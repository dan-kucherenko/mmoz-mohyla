#include <opencv2/core/core.hpp>
#pragma once

void decrease_image_scale(const cv::Mat& in_image,const cv::Mat& out_image, const int n = 2);